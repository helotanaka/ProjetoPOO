package br.com.cesarschool.poo.titulos.utils;

public class ComparadorPadrao {

}
