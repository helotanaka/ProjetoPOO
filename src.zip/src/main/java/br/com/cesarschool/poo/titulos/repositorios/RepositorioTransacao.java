package br.com.cesarschool.poo.titulos.repositorios;

import br.com.cesarschool.poo.titulos.entidades.Transacao;
import br.gov.cesarschool.poo.daogenerico.DAOSerializadorObjetos;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

public class RepositorioTransacao extends RepositorioGeral {

	private static final String CAMINHO_ARQUIVO = "Transacao";

	@Override
	public Class<?> getClasseEntidade() {
		return Transacao.class;
	}

	@Override
	public DAOSerializadorObjetos getDao() {
		return dao;
	}

	public void incluir(Transacao transacao) {
		File diretorio = new File(CAMINHO_ARQUIVO);
		if (!diretorio.exists()) {
			diretorio.mkdirs();
		}
		String caminhoArquivo = diretorio + File.separator + transacao.getIdUnico();
		try {
			Files.writeString(Paths.get(caminhoArquivo), formatarTransacao(transacao));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private String formatarTransacao(Transacao transacao) {
		return "Entidade Crédito: " + transacao.getEntidadeCredito().getNome() + "\n" +
				"Entidade Débito: " + transacao.getEntidadeDebito().getNome() + "\n" +
				"Valor: " + transacao.getValorOperacao() + "\n" +
				"Data e Hora: " + transacao.getDataHoraOperacao() + "\n";
	}

	public Transacao[] buscarPorEntidadeCredora(long identificadorEntidadeCredito) {
		return Arrays.stream(buscarTodos())
				.filter(transacao -> transacao.getEntidadeCredito().getIdentificador() == identificadorEntidadeCredito)
				.toArray(Transacao[]::new);
	}

	public Transacao[] buscarPorEntidadeDebito(long identificadorEntidadeDebito) {
		return Arrays.stream(buscarTodos())
				.filter(transacao -> transacao.getEntidadeDebito().getIdentificador() == identificadorEntidadeDebito)
				.toArray(Transacao[]::new);
	}
}
